import numpy as np
from model import read_model
from assembly import build_LM, assemble_K, check_symmetric
from solver import solve_with_reduction
from postprocess import post_process

def run_case(json_path, case_name):
    print("="*60)
    print(f"开始计算：{case_name}")
    print("="*60)

    # 1. 前处理
    model = read_model(json_path)
    total_dof = model["total_dof"]
    ndof = model["ndof"]
    nel = model["nel"]
    nen = model["nen"]
    fixed_dof = model["fixed_dof"]
    fixed_val = model["fixed_val"]
    F = model["F"]

    # 2. 生成LM对号矩阵
    LM = build_LM(model["IEN"], ndof, nel, nen)
    print(f"\n对号矩阵 LM:\n{LM}")

    # 3. 组装总体刚度矩阵
    K = assemble_K(model, LM)
    print(f"\n总体刚度矩阵 K:\n{np.round(K, 4)}")

    # 校验对称性
    sym_flag = check_symmetric(K)
    print(f"\n总体刚度矩阵是否对称: {sym_flag}")

    # 校验边界前矩阵奇异性
    det_K = np.linalg.det(K)
    print(f"施加边界前 K 行列式 = {det_K:.2e} (接近0 → 矩阵奇异)")

    # 4. 求解方程
    d_total, R, free_dof = solve_with_reduction(K, F, fixed_dof, fixed_val)
    print(f"\n全域节点位移 d:\n{np.round(d_total, 6)}")
    print(f"\n约束自由度反力 R:\n{np.round(R, 6)}")

    # 校验缩减后矩阵非奇异
    K_FF = K[np.ix_(free_dof, free_dof)]
    det_Kff = np.linalg.det(K_FF)
    print(f"缩减后刚度矩阵 K_FF 行列式 = {det_Kff:.2e} (非零 → 矩阵非奇异)")

    # 5. 后处理
    post_process(model, LM, d_total)

if __name__ == "__main__":
    # 运行算例1：一维两杆
    run_case("case1_1d.json", "算例1：一维两单元杆结构")
    # 运行算例2：二维桁架
    run_case("case2_2d.json", "算例2：二维两杆桁架结构")