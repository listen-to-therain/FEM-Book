import numpy as np

def get_element_info(elem_nodes, node_coords):
    """计算单元长度、方向余弦 c/s"""
    n1, n2 = elem_nodes
    x1, y1 = node_coords[n1]
    x2, y2 = node_coords[n2]
    dx = x2 - x1
    dy = y2 - y1
    L = np.hypot(dx, dy)
    c = dx / L if L != 0 else 0.0
    s = dy / L if L != 0 else 0.0
    return L, c, s

def calc_ke(elem_nodes, node_coords, E, A, nsd):
    """计算单元刚度矩阵 Ke"""
    L, c, s = get_element_info(elem_nodes, node_coords)
    EA_L = E * A / L

    if nsd == 1:
        # 一维杆单元 Ke (2×2)
        Ke = EA_L * np.array([
            [1, -1],
            [-1, 1]
        ], dtype=np.float64)
    elif nsd == 2:
        # 二维桁架单元 Ke (4×4)
        mat = np.array([
            [c**2,   c*s,  -c**2,  -c*s],
            [c*s,    s**2, -c*s,   -s**2],
            [-c**2, -c*s,   c**2,   c*s],
            [-c*s,  -s**2,  c*s,    s**2]
        ], dtype=np.float64)
        Ke = EA_L * mat
    else:
        raise ValueError("仅支持1D/2D单元")
    return Ke, L, c, s

def calc_stress_force(de, E, L, c, s, nsd):
    """计算单元应力、轴力"""
    if nsd == 1:
        vec = np.array([-1, 1])
    else:
        vec = np.array([-c, -s, c, s])
    sigma = E / L * np.dot(vec, de)
    force = sigma * (E * 0 + 1)  # 轴力 = 应力 × 截面积
    return sigma, force