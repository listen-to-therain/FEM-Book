import numpy as np
# 先设置绘图后端再导入plt，避免交互报错
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False

def alpha_supg(Pe):
    """SUPG最优稳定参数 α = coth(Pe) - 1/Pe"""
    if abs(Pe) < 1e-10:
        return 0.0
    coth = np.cosh(Pe) / np.sinh(Pe)
    return coth - 1.0 / Pe

def element_matrix(kappa, v, le, alpha):
    """人工扩散稳定单元矩阵（作业简化实现）"""
    kappa_bar = kappa + alpha * v * le / 2.0
    Ke = np.array([
        [kappa_bar / le, -kappa_bar / le],
        [-kappa_bar / le, kappa_bar / le]
    ]) + v / 2.0 * np.array([
        [-1.0, 1.0],
        [-1.0, 1.0]
    ])
    return Ke

def solve_advection_diffusion(nel, L, v, kappa, alpha):
    le = L / nel
    nn = nel + 1
    x = np.linspace(0, L, nn)
    K = np.zeros((nn, nn))
    for e in range(nel):
        Ke = element_matrix(kappa, v, le, alpha)
        n0 = e
        n1 = e + 1
        K[n0, n0] += Ke[0, 0]
        K[n0, n1] += Ke[0, 1]
        K[n1, n0] += Ke[1, 0]
        K[n1, n1] += Ke[1, 1]
    R = np.zeros(nn)
    fixed0 = 0
    fixedL = nn - 1
    free = np.arange(1, nn - 1)
    d0 = 0.0
    dL = 1.0
    rhs = R[free] - K[free, fixed0] * d0 - K[free, fixedL] * dL
    Kff = K[np.ix_(free, free)]
    theta_free = np.linalg.solve(Kff, rhs)
    theta_free = theta_free.ravel()
    theta_num = np.zeros(nn)
    theta_num[fixed0] = d0
    theta_num[fixedL] = dL
    theta_num[free] = theta_free
    Pe_global = v * L / kappa
    theta_exact = (np.exp(v * x / kappa) - 1.0) / (np.exp(Pe_global) - 1.0)
    # 修复：变量大写K，不是小写k
    return x, theta_num, theta_exact, K

def calc_max_err(num, exact):
    return np.max(np.abs(num - exact))

def run_case(Pe_target, nel=20, L=1.0, v=1.0):
    le = L / nel
    kappa = v * le / (2 * Pe_target)
    Pe_elem = Pe_target
    print("="*60)
    print(f"单元Pe = {Pe_elem:.2f}, kappa = {kappa:.6f}, 单元长度le={le:.4f}")
    alpha_gal = 0.0
    alpha_upw = 1.0
    alpha_sp = alpha_supg(Pe_elem)
    print(f"Galerkin alpha={alpha_gal}, 迎风alpha={alpha_upw}, SUPG alpha={alpha_sp:.6f}")

    # 全部5个参数完整传入
    x, theta_gal, theta_ex, K_gal = solve_advection_diffusion(nel, L, v, kappa, alpha_gal)
    x, theta_upw, _, _ = solve_advection_diffusion(nel, L, v, kappa, alpha_upw)
    x, theta_sp, _, _ = solve_advection_diffusion(nel, L, v, kappa, alpha_sp)

    err_gal = calc_max_err(theta_gal, theta_ex)
    err_upw = calc_max_err(theta_upw, theta_ex)
    err_sp  = calc_max_err(theta_sp, theta_ex)

    print(f"最大误差：标准Galerkin={err_gal:.6f}, 迎风={err_upw:.6f}, SUPG(人工扩散型)={err_sp:.6f}")
    plt.figure(figsize=(9,5), dpi=120)
    plt.plot(x, theta_ex, 'k-', lw=2, label='精确解')
    plt.plot(x, theta_gal, 'r--', lw=1.5, label='标准Galerkin')
    plt.plot(x, theta_upw, 'g-.', lw=1.5, label='迎风格式(α=1)')
    plt.plot(x, theta_sp, 'b:', lw=1.8, label='SUPG稳定化')
    plt.xlabel("$x$")
    plt.ylabel("$\\theta(x)$")
    plt.title(f"一维对流扩散 nel={nel}, Pe={Pe_target}")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.savefig(f"Pe_{Pe_target}.png", bbox_inches='tight')
    plt.close()
    print(f"图像 Pe_{Pe_target}.png 已生成\n")

    if abs(Pe_target - 3.0) < 0.01:
        print("\n===== Pe=3 标准Galerkin总体矩阵分析 =====")
        print(np.round(K_gal,4))
        is_sym = np.allclose(K_gal.T, K_gal)
        print(f"矩阵是否对称：{is_sym}")
        eig = np.linalg.eigvals(K_gal)
        min_eig = np.min(np.real(eig))
        print(f"最小特征值：{min_eig:.4f}")
        # 修正特征值判断逻辑
        if min_eig < -1e-8:
            print("矩阵存在负特征值，非正定（对流项破坏正定）")
        elif abs(min_eig) < 1e-8:
            print("矩阵存在零特征值，奇异")
        else:
            print("矩阵正定")
    return x, theta_gal, theta_upw, theta_sp, theta_ex, err_gal, err_upw, err_sp

if __name__ == "__main__":
    print("########## Pe=0.1 扩散占优 ##########")
    run_case(Pe_target=0.1, nel=20, L=1, v=1)
    print("\n########## Pe=3.0 对流占优 ##########")
    run_case(Pe_target=3.0, nel=20, L=1)

    # 网格收敛附加题（取消注释运行）
    # print("\n########## 网格加密收敛测试 ##########")
    # Pe_fix = 3.0
    # v=1;L=1
    # nel_list = [10,20,40,80]
    # eg,eu,es = [],[],[]
    # for n in nel_list:
    #     _,tg,tu,ts,tex,eg_,eu_,es_ = run_case(Pe_fix,n,L,v)
    #     eg.append(eg_)
    #     eu.append(eu_)
    #     es.append(eg_)
    # plt.figure()
    # plt.plot(nel_list, eg, 'o-', label="Galerkin")
    # plt.plot(nel_list, eu, 's-', label="迎风")
    # plt.plot(nel_list, es, '^-', label="SUPG")
    # plt.xlabel("单元数 nel")
    # plt.ylabel("最大节点误差")
    # plt.title("Pe=3 网格收敛曲线")
    # plt.legend()
    # plt.grid()
    # plt.save("converge_curve.png")
    # plt.close()