import numpy as np


# --------------------------
# 三维杆单元刚度矩阵（正确公式）
# --------------------------
def truss3d_element_stiffness(x1, x2, E, A):
    x1 = np.array(x1, dtype=float)
    x2 = np.array(x2, dtype=float)
    dx = x2[0] - x1[0]
    dy = x2[1] - x1[1]
    dz = x2[2] - x1[2]
    L = np.sqrt(dx ** 2 + dy ** 2 + dz ** 2)

    if L < 1e-12:
        raise ValueError("错误：两个节点重合，无效杆单元")

    cx = dx / L
    cy = dy / L
    cz = dz / L

    lam = np.array([[cx, cy, cz, -cx, -cy, -cz]])
    k = E * A / L
    Ke = k * (lam.T @ lam)

    return L, np.array([cx, cy, cz]), Ke


# --------------------------
# 应变、应力、轴力
# --------------------------
def truss3d_element_stress(x1, x2, E, A, de):
    L, cs, _ = truss3d_element_stiffness(x1, x2, E, A)
    cx, cy, cz = cs
    de = np.array(de).reshape(6, 1)
    B = np.array([[-cx, -cy, -cz, cx, cy, cz]]) / L
    eps = (B @ de).item()
    sig = E * eps
    N = sig * A
    return eps, sig, N


# --------------------------
# 矩阵性质检查
# --------------------------
def check_matrix(Ke):
    print("\n===== 刚度矩阵性质检查 =====")
    # 1. 对称性检查 (使用 allclose 处理浮点误差)
    sym = np.allclose(Ke, Ke.T)

    # 2. 奇异性 & 秩检查
    rank = np.linalg.matrix_rank(Ke)
    singular = rank < Ke.shape[0]

    # 3. 半正定性检查 (核心修正)
    eig = np.real(np.linalg.eigvals(Ke))
    max_eig = np.max(np.abs(eig))  # 找到绝对值最大的特征值作为参照

    # 相对容差：如果特征值大于 - (最大特征值量级 * 1e-8)，则认为它是非负的
    # 加上 max(1.0) 是为了防止所有特征值都是0（零矩阵）导致参照量级过小
    tol = max_eig * 1e-8 if max_eig > 1.0 else 1e-8
    semi_pos = np.all(eig >= -tol)

    # 4. 刚体位移校验：三维自由杆件应该有 5 个零特征值 (秩为1)
    expected_rank = 1
    rank_correct = (rank == expected_rank)

    print(f"对称性  ：{' 对称' if sym else ' 错误'}")
    print(f"奇异性  ：{' 奇异（秩=%d）' % rank if singular else ' 非奇异'}")
    print(f"秩校验  ：{' 秩为1（含5个刚体位移）' if rank_correct else ' 移异常（秩=%d）' % rank}")
    print(f"半正定性：{' 半正定' if semi_pos else ' 错误（存在显著负特征值）'}")

    # 可选：打印特征值供调试观察
    # print(f"特征值  ：{np.sort(eig)}")


# --------------------------
# 刚体位移测试
# --------------------------
def rigid_test(x1, x2, E, A):
    print("\n===== 刚体位移测试 =====")
    de_rigid = [0.001, 0.002, 0.003, 0.001, 0.002, 0.003]
    eps, sig, N = truss3d_element_stress(x1, x2, E, A, de_rigid)

    # 浮点数判断：轴力绝对值小于一个极小量即视为0
    if abs(N) < 1e-6:
        print(f"应变：{eps:.2e}")
        print(f"应力：{sig:.2e} Pa")
        print(f"轴力：{N:.2e} N")
        print(" 刚体位移无内力，正确")
    else:
        print(" 刚体位移产生了内力，公式有误！")


# ==========================
# 【交互式输入参数】
# ==========================
if __name__ == "__main__":
    print("===== 三维杆单元有限元计算（交互式）=====")
    print("请按提示输入：\n")

    # 输入节点
    x1 = list(map(float, input("节点1坐标 x y z：").split()))
    x2 = list(map(float, input("节点2坐标 x y z：").split()))
    E_gpa = float(input("弹性模量 E (GPa)："))
    E = E_gpa * 1e9
    A = float(input("截面积 A (m²)："))
    de = list(map(float, input("节点位移 u1 v1 w1 u2 v2 w2：").split()))

    # 计算
    L, cs, Ke = truss3d_element_stiffness(x1, x2, E, A)
    eps, sig, N = truss3d_element_stress(x1, x2, E, A, de)

    # 输出结果
    print("\n===== 计算结果 =====")
    print(f"杆长 L = {L:.4f} m")
    print(f"方向余弦 cx={cs[0]:.3f} cy={cs[1]:.3f} cz={cs[2]:.3f}")
    print(f"应变 ε = {eps:.4e}")
    print(f"应力 σ = {sig / 1e6:.3f} MPa")
    print(f"轴力 N = {N:.3f} N")

    # ======================
    # 【显示完整刚度矩阵】
    # ======================
    print("\n======================================")
    print("        求得的 6×6 单元刚度矩阵 Ke        ")
    print("======================================")
    np.set_printoptions(precision=4, suppress=True)  # 控制小数位数
    print(Ke)

    # 矩阵检查与刚体测试
    check_matrix(Ke)
    rigid_test(x1, x2, E, A)