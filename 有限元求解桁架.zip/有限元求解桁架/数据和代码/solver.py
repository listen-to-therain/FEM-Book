import numpy as np

def solve_with_reduction(K, F, fixed_dof, fixed_val):
    """缩减法施加边界条件，求解位移与约束反力"""
    total_dof = K.shape[0]
    all_dof = np.arange(total_dof)
    # 未知自由度 F区，已知自由度 E区
    free_dof = np.setdiff1d(all_dof, fixed_dof)

    # 分块矩阵
    K_FF = K[np.ix_(free_dof, free_dof)]
    K_EF = K[np.ix_(fixed_dof, free_dof)]
    K_FE = K[np.ix_(free_dof, fixed_dof)]
    K_EE = K[np.ix_(fixed_dof, fixed_dof)]

    F_F = F[free_dof]
    d_E = fixed_val

    # 求解未知位移: K_FF * d_F = F_F - K_FE @ d_E
    rhs = F_F - np.dot(K_FE, d_E)
    d_F = np.linalg.solve(K_FF, rhs)

    # 重构全域位移
    d_total = np.zeros(total_dof, dtype=np.float64)
    d_total[free_dof] = d_F
    d_total[fixed_dof] = d_E

    # 计算约束反力 R = K_EF*d_F + K_EE*d_E - F_E
    F_E = F[fixed_dof]
    R = np.dot(K_EF, d_F) + np.dot(K_EE, d_E) - F_E

    return d_total, R, free_dof