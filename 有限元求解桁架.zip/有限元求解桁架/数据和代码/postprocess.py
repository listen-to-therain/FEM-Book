import numpy as np
from element import  get_element_info,calc_stress_force
def post_process(model_data, LM, d_total):
    """后处理：遍历所有单元，输出结果"""
    nel = model_data["nel"]
    IEN = model_data["IEN"]
    node_coords = model_data["node_coords"]
    E_list = model_data["E"]
    A_list = model_data["A"]
    nsd = model_data["nsd"]
    ndof = model_data["ndof"]
    nen = model_data["nen"]

    print("\n===== 单元后处理结果 =====")
    for e in range(nel):
        # 提取单元位移
        de = d_total[LM[:, e]]
        elem_nodes = IEN[e]
        E = E_list[e]
        A = A_list[e]

        L, c, s = get_element_info(elem_nodes, node_coords)
        sigma, force = calc_stress_force(de, E, L, c, s, nsd)

        print(f"【单元 {e+1}】")
        print(f"  单元长度 L = {L:.6f}")
        if nsd == 2:
            print(f"  方向余弦 c={c:.6f}, s={s:.6f}")
        print(f"  单元应力 σ = {sigma:.6f}")
        print(f"  单元轴力 N = {force:.6f}\n")