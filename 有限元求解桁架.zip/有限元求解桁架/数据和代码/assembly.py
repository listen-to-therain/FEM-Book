import numpy as np
from element import calc_ke
def build_LM(IEN, ndof, nel, nen):
    """生成对号矩阵 LM: (单元内自由度, 单元号) → 全局自由度"""
    LM = np.zeros((nen * ndof, nel), dtype=int)
    for e in range(nel):
        nodes = IEN[e]
        idx = 0
        for node in nodes:
            for d in range(ndof):
                LM[idx, e] = node * ndof + d
                idx += 1
    return LM

def assemble_K(model_data, LM):
    """直接组装总体刚度矩阵 K"""
    total_dof = model_data["total_dof"]
    nel = model_data["nel"]
    IEN = model_data["IEN"]
    node_coords = model_data["node_coords"]
    E_list = model_data["E"]
    A_list = model_data["A"]
    nsd = model_data["nsd"]

    K = np.zeros((total_dof, total_dof), dtype=np.float64)

    for e in range(nel):
        elem_nodes = IEN[e]
        E = E_list[e]
        A = A_list[e]
        Ke, _, _, _ = calc_ke(elem_nodes, node_coords, E, A, nsd)
        # 直接组装 K[LM[a,e], LM[b,e]] += Ke[a,b]
        for a in range(Ke.shape[0]):
            for b in range(Ke.shape[1]):
                ga = LM[a, e]
                gb = LM[b, e]
                K[ga, gb] += Ke[a, b]
    return K

def check_symmetric(K, tol=1e-8):
    """校验矩阵对称性"""
    is_sym = np.allclose(K, K.T, atol=tol)
    return is_sym