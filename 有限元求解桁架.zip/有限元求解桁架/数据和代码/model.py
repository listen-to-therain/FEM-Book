import json
import numpy as np


def read_model(json_path):
    """读取JSON模型文件，统一转为0索引"""
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 基础参数
    nsd = data["nsd"]
    ndof = data["ndof"]
    nnp = data["nnp"]
    nel = data["nel"]
    nen = data["nen"]
    E = np.array(data["E"], dtype=np.float64)
    A = np.array(data["CArea"], dtype=np.float64)

    # 节点坐标
    x = np.array(data["x"], dtype=np.float64)
    y = np.array(data["y"], dtype=np.float64)
    node_coords = np.column_stack((x, y))

    # 单元连接 IEN: 原1索引 → 转为0索引
    IEN = np.array(data["IEN"], dtype=int) - 1

    # 边界条件：自由度1索引 → 0索引
    fixed_dof = np.array(data["fixed_dof"], dtype=int) - 1
    fixed_val = np.array(data["fixed_value"], dtype=np.float64)

    # 节点载荷
    force_dof = np.array(data["force_dof"], dtype=int) - 1
    force_val = np.array(data["force_value"], dtype=np.float64)

    # 总自由度数
    total_dof = nnp * ndof

    # 初始化总载荷向量
    F = np.zeros(total_dof, dtype=np.float64)
    F[force_dof] = force_val

    return {
        "nsd": nsd, "ndof": ndof, "nnp": nnp, "nel": nel, "nen": nen,
        "E": E, "A": A, "node_coords": node_coords, "IEN": IEN,
        "fixed_dof": fixed_dof, "fixed_val": fixed_val,
        "total_dof": total_dof, "F": F
    }